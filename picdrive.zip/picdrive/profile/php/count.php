<?php
require("../../php/database.php");
session_start();
$username=$_SESSION['username']; 
$id="select id from users where username='$username'";
$data=$db->query($id);
$get_id=$data->fetch_assoc();
$table_name="user_".$get_id['id'];
$count_photo="select count(id) as total from $table_name";
$pic=$db->query($count_photo);
$pic_no=$pic->fetch_assoc();
echo $pic_no['total']." PHOTO";
$_SESSION['table_name']=$table_name;
?>



<?php
$db->close();
?>