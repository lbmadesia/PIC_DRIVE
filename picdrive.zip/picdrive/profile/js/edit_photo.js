

$(document).ready(function(){
	$.ajax({
		type:'POST',
		url:'image_load.php',
		success:function(response){
			
	setTimeout(function(){

//rename coding------------------------------------------------------------------------
$(document).ready(function(){
	
		
	$(".edit-icon").click(function(){
		var image_path=$(this).attr("data-location");
		var footer=this.parentElement;
		var span=footer.getElementsByTagName("span")[0];
		span.contentEditable="true";
		span.focus();
		var old_name=span.innerHTML;
		var icon=footer.getElementsByClassName("save-icon")[0];
		$(this).addClass("d-none");
		$(icon).removeClass("d-none");
		$(icon).click(function(){
			var photo_name=span.innerHTML;
			$.ajax({
				type:"POST",
				url:"php/rename.php",
				data:{
					photo_name:photo_name,
					photo_path:image_path
				},
				cache:false,
				beforeSend:function(){
					var loader=footer.getElementsByClassName("loader")[0];
					$(loader).removeClass("d-none");
					$(icon).addClass("d-none");
				},
				success:function(response){
					if(response.trim() == "file already exits")
					{
						alert(response);
						$(loader).addClass("d-none");
						$(icon).removeClass("d-none");
						span.focus();
					}
					else if(response.trim() == "update success")
					{
						span.innerHTML=photo_name;
						span.contentEditable="false";
						var loader=footer.getElementsByClassName("loader")[0];
						$(loader).addClass("d-none");
						$(icon).addClass("d-none");
						var edit_icon=footer.getElementsByClassName("edit-icon")[0];
						$(edit_icon).removeClass("d-none");
						var previous_download_link=footer.getElementsByClassName("download-icon")[0].getAttribute("data-location");
						var current_link=previous_download_link.replace(old_name,photo_name);
						footer.getElementsByClassName("download-icon")[0].setAttribute("data-location",current_link);
						footer.getElementsByClassName("download-icon")[0].setAttribute("file-name",photo_name);
						footer.getElementsByClassName("delete-icon")[0].setAttribute("data-location",current_link);
						
						footer.getElementsByClassName("edit-icon")[0].setAttribute("data-location",current_link);
						footer.getElementsByClassName("edit-icon")[0].setAttribute("file-name",photo_name);
						footer.getElementsByClassName("edit-icon")[0].setAttribute("data-location",current_link);
						
						
						
					}
				}
			});
		});
		
		
	});

});

//download pic coding start here----------------------------------------------------
$(document).ready(function(){
	$(".download-icon").click(function(){
		var dow=$(this).attr("data-location");
		var file_name=$(this).attr("file-name");
		var a=document.createElement("A");
		a.href=dow;
		a.download=file_name;
		a.click();
	});
});

//delete photo coding---------------------------------------------------------------------
$(document).ready(function(){
	$(".delete-icon").click(function(){
		var del_icon=this;
		$.ajax({
			type:"POST",
			url:"php/delete.php",
			cache:false,
			data:{
				photo_path:$(this).attr("data-location")
			},
			beforeSend:function(){
				$(this).removeClass("fa fa-trash");
				$(this).addClass("fa fa-spinner fa-spin")
			},
			success:function(response){
					del_icon.parentElement.parentElement.style.display="none";
			}
		});
	});
});
},3000);
		}
	});
});
