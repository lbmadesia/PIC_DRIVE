$(document).ready(function(){
	$(".show-icon").click(function(){
		var password=$(".password").attr("type");
		if(password == "password")
		{
			$(".password").attr("type","text");
			$(this).css("color","black");
		}
		else{
			$(".password").attr("type","password");
			$(this).css("color","#ccc");
		}
	});
});