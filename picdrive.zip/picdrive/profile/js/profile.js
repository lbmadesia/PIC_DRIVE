$(document).ready(function(){
	$(".upload-icon").click(function(){
		var input=document.createElement("INPUT");
		input.type="file";
		input.accept="image/*";
		input.click();
		input.onchange=function(){
			var file=new FormData();
			file.append("data",this.files[0]);
			$.ajax({
				type:"POST",
				url:"php/upload.php",
				data:file,
				contentType:false,
				processData:false,
				cache:false,
				xhr:function(){
					var request= new XMLHttpRequest();
					request.upload.onprogress=function(e){
						var loaded=(e.loaded/1024/1024).toFixed(2);
						var total=(e.total/1024/1024).toFixed(2);
						var per=((loaded*100)/total).toFixed(2);
						$(".progress-control").css({width:per+"%"});
						$(".progress-per").html(per+"%"+" "+loaded+"MB /"+total+"MB");
					}
					return request;
				},
				beforeSend:function(){
					$(".upload-file").html("Uploading file....");
					$(".upload-icon").css({
						opacity:"0.5",
						pointerEvents:"none",
						
						});
						$(".upload-progress-con").removeClass("d-none");
						$(".progress-detail").removeClass("d-none");
				},
				success:function(response){
				if(response.trim() == 'updated successfully')
				{
				var message=document.createElement("DIV");
				message.className='alert alert-light shadow-lg rounded-0';
				message.innerHTML="<b>"+response+"</b>";
				$(".notice").html(message);
				setTimeout(function(){
				$(".upload-file").html("UPLOAD FILES");	
				$(".upload-icon").css({
						opacity:"1",
						pointerEvents:"inherit",
						
						});
				$(".upload-progress-con").addClass("d-none");
				$(".progress-detail").addClass("d-none");
				$(".notice").html(" ");
				},3000);
				}
				else
				{
				var message=document.createElement("DIV");
				message.className='alert alert-primary shadow-lg rounded-0';
				message.innerHTML="<b>"+response+"</b>";
				$(".notice").html(message);
				setTimeout(function(){
				$(".upload-file").html("UPLOAD FILES");	
				$(".upload-icon").css({
						opacity:"1",
						pointerEvents:"inherit",
						
						});
				$(".upload-progress-con").addClass("d-none");
				$(".progress-detail").addClass("d-none");
				$(".notice").html(" ");
				},3000);
				}
				$.ajax({
					type:"POST",
					url:"php/count.php",
					beforeSend:function(){
						$(".photo-count").html("updating........");
					},
					cache:false,
					success:function(response){
						$(".photo-count").html(response);
					}
				});
				
				$.ajax({
					type:"POST",
					url:"php/memory_size.php",
					beforeSend:function(){
					$(".memory").html("updating......");	
					},
					cache:false,
					success:function(response){
					var data1=JSON.parse(response);
					var memory_status=data1[0];
					var free_space=data1[1];
					var per=data1[2]+"%";
					$(".progress-bar").css({width:per});
					$(".memory").html(" ");
					$(".memory").html(memory_status);
					
					$("#free").html("FREE SPACE : "+free_space); 
					}
				});
				
				
				}
			});
		}
		
	});
});