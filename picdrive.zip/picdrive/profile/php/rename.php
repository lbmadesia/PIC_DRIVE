<?php
require("../../php/database.php");
session_start();
$username=$_SESSION['username'];
$photo_name=$_POST['photo_name'];
$photo_path=$_POST['photo_path'];
$old_path="../".$photo_path;


$pathinfo=pathinfo($photo_path);
$dirname=$pathinfo['dirname'];
$extension=$pathinfo['extension'];
$new_pic_name=$photo_name.".".$extension;
$newpath="../".$dirname."/".$photo_name.".".$extension;
if(file_exists($newpath))
{
	echo "file already exits";
}
else
{
	if(rename("../".$photo_path,$newpath))
	{
		$check="select id from users where username='$username'";
		$data=$db->query($check);
		$id=$data->fetch_assoc();
		$get_id=$id['id'];
		$table_name="user_".$get_id;
		$up="update $table_name SET image_name='$new_pic_name',image_path='$newpath' where image_path='$old_path'";
		if($db->query($up))
		{
			echo "update success";
		}
		else
		{
			echo "update failed";
		}
	}
	else
	{
		echo "failed";
	}
}



?>



<?php
$db->close();
?>