<?php
require("../../php/database.php");
session_start();
$username=$_SESSION['username'];
$table_name=$_SESSION['table_name'];
$image_path="../".$_POST['photo_path'];
if(unlink($image_path))
{
	//get used storage---------------------------------
	$used_storage="select used_storage from users where username='$username'";
	$response=$db->query($used_storage);
	$data=$response->fetch_assoc();
	$used_space=$data['used_storage'];
	
	//get image size------------------------------------
	$get_image_size="select image_size from $table_name where image_path='$image_path'";
	$get_response=$db->query($get_image_size);
	$data1=$get_response->fetch_assoc();
	$image_size=$data1['image_size'];
	//update storage------------------------------------------
	$storage=$used_space-$image_size;
	$update="update users set used_storage='$storage' where username='$username'";
	$update_response=$db->query($update);
	
	//update end----------------
	$del="delete from $table_name where image_path='$image_path'";
	if($db->query($del))
	{
		echo "delete success";
	}
	else
	{
		echo "delete failed";
	}
}
else
{
	echo "delete failed";
}



?>



<?php
$db->close();
?>