$(document).ready(function(){
	$(".btn-sign").click(function(e){
		e.preventDefault();
		var username=btoa($("#login-email").val());
		var username1=$("#login-email").val();
		var pass=btoa($("#login-password").val());
		$.ajax({
			type:"post",
			url:"php/login.php",
			data:{
				username:username,
				pass:pass
			},
			cache:false,
			beforeSend:function(){
				$(".btn-sign").html("processing please wait...");
				$(".btn-sign").attr("disabled","disabled");
			},
			success:function(response){
				if(response.trim() == "login success")
				{
					window.location="profile/profile.php";
				}
				else if(response.trim() == "login pending")
				{
					$("#login-form").fadeOut(500,function(){
						$("#my").css("display","block");
						$(".activate-btn-sign").click(function(){
							$.ajax({
								type:"post",
								url:"php/valid_activate.php",
								data:{
									username:username1,
									code:$("#code-sign").val()
									
								},
								cache:false,
								beforeSend:function(){
									$(".activate-btn-sign").html("please wait we are checking");
									$(".activate-btn-sign").attr("disabled","disabled");
								},
								success:function(response){
									if(response.trim() == "user verified")
									{
										window.location="profile/profile.php"
									}
									else
									{
										$(".activate-btn-sign").html("Activate Now");
										$(".activate-btn-sign").removeAttr("disabled");
										$("#code-sign").val("");
										var notice=document.createElement("DIV");
										notice.className="alert alert-warning";
										notice.innerHTML="<b>Wrong activation code</b>";
										$(".login-notice").append(notice);
										setTimeout(function(){
											$(".login-notice").html("");
										},3000);
									}
								}
							});
						});
					});
				}
				else if(response.trim() == "password wrong")
				{
					var message=document.createElement("DIV");
					message.className="alert alert-warning";
					message.innerHTML="<b>wrong password please try again later</b>";
					$(".login-notice").append(message);
					$("#login-form").trigger('reset');
					$(".btn-sign").html("Login Now");
					$(".btn-sign").removeAttr("disabled");
					setTimeout(function(){
						$(".login-notice").html(" ");
					},2000);
					
				}
				else
				{
					message=document.createElement("DIV");
					message.className="alert alert-warning";
					message.innerHTML="<b>user not found please sign up</b>";
					$(".login-notice").append(message);
					$("#login-form").trigger('reset');
					$(".btn-sign").html("Login Now");
					$(".btn-sign").removeAttr("disabled");
					setTimeout(function(){
						$(".login-notice").html(" ");
					},2000);
				}
			}
		});
	});
});