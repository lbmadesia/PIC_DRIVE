<?php
session_start();
$username=$_SESSION['username'];
if(empty($username))
{
	header("Location:../index.php");
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<meta lang="en-us">
<meta charset="utf-8">
<meta name="viewport" content= "width = device-width, initial-scale=1">
<title>picdrive</title>
<link rel="stylesheet" href="../style/animate.css">
<link href="https://fonts.googleapis.com/css?family=Francois+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.css">
<link rel="stylesheet" href="../style/bootstrap.css">
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="js/profile.js"></script>
<script src="js/edit_photo.js"></script>
<style>
span:focus{
	outline:2px dashed red;
	padding:2px;
	box-shadow:0px 0px 5px grey;
}
i{
	cursor:pointer;
}
</style>
</head>
<body style="background:#FCD0CF">
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
<a class="navbar-brand" href="#">
<?php
require("../php/database.php");
$username=$_SESSION['username'];
$check="select full_name from users where username='$username'";
$data=$db->query($check);
$get=$data->fetch_assoc();
$name=$get['full_name'];
echo $name;

?>
</a>
<ul class="navbar-nav ml-auto">
<li class="navbar-item">
<a class="nav-link" href="php/logout.php">
<i class="fa fa-sign-out" style="font-size:18px"></i>
Logout
</a>
</li>
</ul>
</nav>
<br>
<div class="container mt-5" >
<div class="row load-image">


</div>
<div class="d-flex justify-content-center" id="con">
<i class="fa fa-spinner fa-spin mk d-none" style="font-size:30px"></i>
</div>
</div>
<!-----------modal start------------------------------>
<div class="modal animated bounceIn" id="modal">
<div class="modal-dialog">
<i class="fa fa-times-circle float-right text-light" data-dismiss="modal"></i>
<div class="modal-content">
<div class="progress w-100" style="height:10px;">
<div class="progress-bar image-loader">
</div>
</div>
<div class="modal-body"></div>
</div>
</div> 
</div>
<script>
$(document).ready(function(){
	$.ajax({
		type:"POST",
		url:"image_load.php",
		success:function(response){
			   
		}
	});
});
setTimeout(function(){
$(document).ready(function(){
	$(".pic").each(function(){
		$(this).click(function(){
			$(".image-loader").css({width:"0%"});
			$("#modal").modal();
			var image=document.createElement("IMG");
			var url=$(this).attr("data-location");
			$.ajax({
				type:"POST",
				url:url,
				xhr:function(){
					var request=new XMLHttpRequest();
					request.responseType="blob";
					request.onprogress=function(e){
					var per=Math.floor((e.loaded*100)/e.total);	
					$(".image-loader").css({
						width:per+"%"
					});
					$(".image-loader").html(per+"%");
					}
					return request;
				},
				beforeSend:function()
				{
				$(".modal-body").html("Please wait....");
				},
				success:function(response){
					var image_url=URL.createObjectURL(response);
					image.src=image_url;
					image.style.width="100%";
					$(".modal-body").html(image);
					
				}
			});
			
		});
	});
});
	
},3000);

//load image coding-----------------------------------
$(document).ready(function(){
	var start_point=0;
	var end_point=12;
	load_image(start_point,end_point);
	function load_image(start_point,end_point)
	{
		$.ajax({
			type:"POST",
			url:"image_load.php",
			cache:false,
			data:{
			start:start_point,
			end:end_point
			},
			beforeSend:function(){
				$(".mk").removeClass("d-none");
			},
			success:function(response){
				$(".load-image").append(response);
				$(".mk").addClass("d-none");
			}
		});
	}
//on scroll
	$(window).scroll(function(){
		var top_height=$(window).scrollTop();
		var browser_height=$(window).height();
		var max_height=top_height+browser_height;
		var webpage_height=$(document).height();
		if(max_height>=webpage_height-10)
		{
			start_point=start_point+end_point; 
			load_image(start_point,end_point);
		}
	});
	
});
//load image end ----------------------------------------------
</script>
</body>
</html>



<?php
$db->close();
?>