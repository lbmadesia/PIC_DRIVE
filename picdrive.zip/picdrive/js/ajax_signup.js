$(document).ready(function(){
	$(".submit-btn").click(function(e){
		e.preventDefault();
		$.ajax({
			type:"post",
			url:"php/sign_up.php",
			data:{
				fullname:btoa($(".name").val()),
				email:btoa($(".email").val()),
				password1:btoa($(".password").val())
			},
			cache:false,
			beforeSend:function(){
				$(".submit-btn").html("processing please wait...");
				$(".submit-btn").attr("disabled","disabled");
			},
			success:function(response){
				if(response.trim() == "sending success")
				{
					$("#signup-form").fadeOut(500,function(){
						$(".activator").removeClass("d-none");
					});
				}
				else
				{
					var message=document.createElement("DIV");
					message.className="alert alert-warning";
					message.innerHTML="<b>something went wrong please try again later</b>"
					$(".signup-notice").append(message);
					$(".submit-btn").html("Register Now");
					$("form").trigger("reset");
					$(".email-icon").css("display","none");
					setTimeout(function(){
						$(".signup-notice").html(" ");
					},2000);
				}
			}
		});
	});
});