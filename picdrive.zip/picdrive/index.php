<!DOCTYPE html>
<html>
<head>
<meta lang="en-us">
<meta charset="utf-8">
<meta name="viewport" content= "width = device-width, initial-scale=1">
<title>picdrive</title>
<link rel="stylesheet" href="style/animate.css">
<link href="https://fonts.googleapis.com/css?family=Francois+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style/index.css">
<link rel="stylesheet" href="style/bootstrap.css">
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/ajax_random_password.js"></script>
<script src="js/index.js"></script>
<script src="js/ajax_user_check.js"></script>
<script src="js/ajax_signup.js"></script>
<script src="js/ajax_activate.js"></script>
<script src="js/ajax_login.js"></script>
</head>
<body style="background:#FCD0CF" class="animated fadeIn slower">
<div class="container-fluid">
<div class="row">
<div class="col-md-4 p-0"><image src="image/main_pic.jpg" class="shadow-lg w-100"></div>
<div class="col-md-4  px-5 py-4">
<h3 class="ml-2 mb-3">SIGN UP</h3>
<form autocomplete="off" id="signup-form">
<input type="text" name="name" class="name" placeholder="ENTER YOUR NAME" required="required">
<div class="email-box">
<input type="email" name="email" class="email" placeholder="EMAIL" required="required">
<i class="fa fa-circle-o-notch fa-spin email-icon" style="font-size:18px;display:none"></i>
</div>
<div class="password-box">
<input type="password" name="password" class="password" placeholder="PASSWORD" required="required">
<i class="fa fa-eye show-icon" style="font-size:18px"></i>
</div>
<button class="btn float-left">CLICK GENERATE TO IMPROVE SECURITY</button>
<button class="btn gen float-right">GENERATE</button>
<button class="btn register mt-3 ml-3 submit-btn" type="submit" disabled="disabled">Register Now</button>
</form>

<div class="signup-notice mt-3">

</div>

<div class="activator px-2 mt-3 d-none">
<span>Please check your email to get activation code</span>
<input type="text" name="code"  id="code" placeholder="activation code" class="my-3 form-control" style="border-radius:50px">
<button class="btn btn-dark activate-btn">Activate Now</button>
</div>
</div>
<div class="col-md-4 px-5 py-4">
<h3 class="ml-2 mb-3">LOGIN</h3>
<form id="login-form">
<input type="email" name="email" class="username" placeholder="USERNAME" required="required" id="login-email">
<div class="password-box-sign">
<input type="password" name="password" class="password-sign" placeholder="PASSWORD" required="required" id="login-password">
<i class="fa fa-eye show-icon-sign" style="font-size:18px"></i>
<button class="btn btn-sign  float-right" type="submit">Login Now</button>
<br>

</div>
</form>

<div class="login-notice p-2 mt-5">

</div>

<div class="login-activator px-2 mt-5" id="my" style="display:none">
<span>Please check your email to get activation code</span>
<input type="text" name="code"  id="code-sign" placeholder="activation code" class="my-3 form-control" style="border-radius:50px">
<button class="btn btn-dark activate-btn-sign">Activate Now</button>
</div>
</div>
</div>
</div>
</body>
</html>