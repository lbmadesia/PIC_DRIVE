<?php
require("../../php/database.php");
session_start();
$username=$_SESSION['username'];
$plans=$_GET['plan'];
$storage=$_GET['storage'];
$purchase_date=date('Y-m-d');
if($plans == 'starter' || $plans == 'free')
{	
//get storage
$select_storage="select storage from users where username='$username'";
$response=$db->query($select_storage);
$data=$response->fetch_assoc();
$all_storage; 
if(empty($_SESSION['renew']))
{
$all_storage=$data['storage']+$storage;
}
else
{
	$all_storage=$data['storage']+0;
}

//update storagege
$cal_date=new DateTime($purchase_date);
$cal_date->add(new DateInterval('P30D'));
$expiry_date=$cal_date->format('Y-m-d');

$update_storage="UPDATE users SET plans = '$plans',storage='$all_storage',purchase_date='$purchase_date',expiry_date='$expiry_date' where username='$username'";

if($db->query($update_storage))
{
	header("Location:../profile.php");
}
else
{
	echo "update failed";
}

}
else
{
	
//update storagege
$cal_date=new DateTime($purchase_date);
$cal_date->add(new DateInterval('P30D'));
$expiry_date=$cal_date->format('Y-m-d');

$update_storage="UPDATE users SET plans = '$plans',storage='0',purchase_date='$purchase_date',expiry_date='$expiry_date' where username='$username'";

if($db->query($update_storage))
{
	header("Location:../profile.php");
}
else
{
	echo "update failed";
}
}



?>

<?php
$db->close();
?>