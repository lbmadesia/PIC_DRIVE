<?php
require("database.php");
$fullname=base64_decode($_POST['fullname']);
$username=base64_decode($_POST['email']);
$password=base64_decode($_POST['password1']);


$pattern="GA0a!b1|cBdN@efg2hCiH3`jkD#lP4OmM%n^JVo\Q5pRE_<q=)SIK9rs6&tT*uUF,L-(vZ/7w~Wx+8yX>zY";
$length=strlen($pattern)-1;
$i;
$code = [];
for($i=0;$i<6;$i++)
{
	$index_num=rand(0,$length);
	$code[]=$pattern[$index_num];
}


$activation_code=implode($code);
$store_user="insert into users(full_name,username,password,activation_code) values('$fullname','$username','$password','$activation_code')";

if($db->query($store_user))
{
	$check_mail=mail($username,"picdrive activation code","Thanks for choosing our product your activation code is here : ".$activation_code);
	if($check_mail)
	{
		echo "sending success";
	}
	else
	{
		echo "sending failed";
	}
}
else
{
	echo "signup failed";
}


?>




<?php
$db->close();
?>