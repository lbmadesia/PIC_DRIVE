<?php

require("../../instamojo/Instamojo.php");
$api = new Instamojo\Instamojo('1dd0a58214a88d7b110854961662e963','b0ba79ad6c511cf6b4627b36d3a6ac2a', 'https://www.instamojo.com');
$amount=$_GET['amount'];
$plan=$_GET['plan'];
$storage=$_GET['storage'];
session_start();
$name=$_SESSION['buyer_name'];
$username=$_SESSION['username'];

try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => "picdrive plans",
        "amount" => $amount,
        "send_email" => true,
		"buyer_name" =>$name,
        "email" => $username,
        "redirect_url" => "http://localhost/PHP/picdrive/profile/php/update_storage.php?plan=".$plan."&storage=".$storage
        ));
    $payment_url=$response['longurl'];
	header("Location:$payment_url");
}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}

?>