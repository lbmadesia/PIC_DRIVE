<?php
require("../../php/database.php");
session_start();
$username=$_SESSION['username']; 
$check="select id from users where username='$username'";
$data=$db->query($check);
$id=$data->fetch_assoc();
$folder_name="../gallery/user_".$id['id']."/";
$file=$_FILES['data'];
$user_path=$file['tmp_name'];
$extension=$file['type'];
$file_name=strtolower($file['name']);
$file_size=round($file['size']/1024/1024,2);
$table_name="user_".$id['id'];
$complete_path=$folder_name.$file_name;
$thumb_path=$folder_name."thumb_".$file_name;

//check free spaces
$check_storage="select plans,storage,used_storage from users where username='$username'";
$space=$db->query($check_storage);
$data=$space->fetch_assoc();
$total=$data['storage'];
$plan=$data['plans'];
$used=$data['used_storage'];
$free=$total-$used;
if($plan == 'free' || $plan == 'starter')
{	
if($file_size < $free)
{
	if(file_exists($folder_name.$file_name))
	{
		echo "file already exits";
	}
	else
	{
		if(move_uploaded_file($user_path,$folder_name.$file_name))
		{
			$store_data="insert into $table_name(image_name,image_path,thumb_path,image_size) values('$file_name','$complete_path','$thumb_path','$file_size')";
			if($db->query($store_data))
			{
				$sum=$used+$file_size;
				$update="UPDATE users SET used_storage='$sum' where username='$username'";
				if($db->query($update))
				{
					if('image/jpeg' == $extension)
					{
						$image_pixel=imagecreatefromjpeg($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagejpeg($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					if('image/png' == $extension)
					{
						$image_pixel=imagecreatefrompng($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagepng($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					
					if('image/gif' == $extension)
					{
						$image_pixel=imagecreatefromgif($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagegif($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					
					if('image/bmp' == $extension)
					{
						$image_pixel=imagecreatefrombmp($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagebmp($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					
					if('image/webp' == $extension)
					{
						$image_pixel=imagecreatefromwebp($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagewebp($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
				}
				else
				{
					echo "upadeted failed";
				}
			}
			else
			{
				echo "failed to store image in database";
			}
		}
		
	}
}
else
{
	echo "file size is too large kindly purchase some memory space";
}

}
else
{
		if(file_exists($folder_name.$file_name))
	{
		echo "file already exits";
	}
	else
	{
		if(move_uploaded_file($user_path,$folder_name.$file_name))
		{
			$store_data="insert into $table_name(image_name,image_path,thumb_path,image_size) values('$file_name','$complete_path','$thumb_path','$file_size')";
			if($db->query($store_data))
			{
				$sum=$used+$file_size;
				$update="UPDATE users SET used_storage='$sum' where username='$username'";
				if($db->query($update))
				{
					if('image/jpeg' == $extension)
					{
						$image_pixel=imagecreatefromjpeg($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagejpeg($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					if('image/png' == $extension)
					{
						$image_pixel=imagecreatefrompng($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagepng($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					
					if('image/gif' == $extension)
					{
						$image_pixel=imagecreatefromgif($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagegif($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					
					if('image/bmp' == $extension)
					{
						$image_pixel=imagecreatefrombmp($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagebmp($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
					
					if('image/webp' == $extension)
					{
						$image_pixel=imagecreatefromwebp($folder_name.$file_name);
						$o_width=imagesx($image_pixel);
						$o_height=imagesy($image_pixel);
						$ratio=100/$o_width;
						$height=$o_height*$ratio;
						$canvas=imagecreatetruecolor(100,$height);
						imagecopyresampled($canvas,$image_pixel,0,0,0,0,100,$height,$o_width,$o_height);
						if(imagewebp($canvas,$thumb_path))
						{
							echo "updated successfully";
						}
						imagedestroy($image_pixel);
					}
				}
				else
				{
					echo "updated failed";
				}
			}
			else
			{
				echo "failed to store image in database";
			}
		}
		
	}
}

?>


<?php
$db->close();
?>