<?php
require("database.php");
$code=$_POST['code'];
$username=$_POST['username'];
$check="select activation_code from users where username='$username' AND activation_code='$code'";
$result=$db->query($check);
if($result->num_rows != 0)
{
	$update="update users set status ='active' where username='$username' AND activation_code='$code'";
	if($db->query($update) == true)
	{
		$get_id="select id from users where username='$username'";
		$get_id_response=$db->query($get_id);
		$id_data=$get_id_response->fetch_assoc();
		$table_name="user_".$id_data['id'];
		$create_table="create table $table_name(
								id int(34) NOT NULL AUTO_INCREMENT,
								image_name varchar(34),
								image_path varchar(55),
								thumb_path varchar(50),
								image_size float(12),
								image_date DATETIME DEFAULT CURRENT_TIMESTAMP,
								PRIMARY KEY(id)
								)";
			if($db->query($create_table))
			{
				mkdir("../profile/gallery/".$table_name);
				echo "user verified";
				session_start();
				$_SESSION['username']=$username;
			}
	}
	else
	{
		echo "activation failed plese try again later";
	}
}

else
{
	echo "wrong activation code";
}

?>


<?php
$db->close();
?>