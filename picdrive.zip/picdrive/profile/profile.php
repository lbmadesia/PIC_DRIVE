<?php
session_start();
$username=$_SESSION['username'];
if(empty($username))
{
	header("Location:../index.php");
	exit;
}

?>

<!DOCTYPE html>
<html>
<head>
<meta lang="en-us">
<meta charset="utf-8">
<meta name="viewport" content= "width = device-width, initial-scale=1">
<title>picdrive</title>
<link rel="stylesheet" href="../style/animate.css">
<link href="https://fonts.googleapis.com/css?family=Francois+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../style/bootstrap.css">
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="js/profile.js"></script>
</head>
<body style="background:#FCD0CF">
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
<a class="navbar-brand" href="#">
<?php
require("../php/database.php");
$username=$_SESSION['username'];
$check="select full_name from users where username='$username'";
$data=$db->query($check);
$get=$data->fetch_assoc();
$name=$get['full_name'];
echo $name;

?>
</a>
<ul class="navbar-nav ml-auto">
<li class="navbar-item">
<a class="nav-link" href="php/logout.php">
<i class="fa fa-sign-out" style="font-size:18px"></i>
Logout
</a>
</li>
</ul>
</nav>
<br>
<div class="notice fixed-top">
</div>
<div class="container-fluid">
<div class="row">
<div class="col-md-3 p-5 border">
<div class="w-100 py-3 bg-white mb-5 rounded-lg shadow-lg d-flex flex-column justify-content-center align-items-center">
<i class="fa fa-folder-open upload-icon" style="font-size:70px;"></i>
<h5 class="upload-file">UPLOAD FILES</h5>
<span id="free">
<?php
$data="select plans,storage,used_storage from users where username='$username'";
$check=$db->query($data);
$response=$check->fetch_assoc();
$storage=$response['storage'];
$used=$response['used_storage'];
$plans=$response['plans'];
if($plans == 'starter' || $plans == 'free')
{
$free=$storage-$used;
echo "FREE SPACE : ".$free;
}
else
{
	echo "FREE SPACE : UNLIMITED";
}
?>
</span>
<div class="progress w-50 my-2 upload-progress-con d-none" style="height:8px">
<div class="progress-bar progress-bar-striped progress-bar-animated progress-control">
</div>
</div>
<div class="progress-detail d-none">
<span class="progress-per"></span>
<i class="fa fa-pause-circle"></i>
<i class="fa fa-times-circle"></i>
</div>
</div>

<div class="w-100 py-3 bg-white mb-5 rounded-lg shadow-lg d-flex flex-column justify-content-center align-items-center" >
<i class="fa fa-database " style="font-size:70px;"></i>
<h5>MEMORY STATUS</h5>
<span class="memory">
<?php
require("../php/database.php");
$data="select plans,storage,used_storage from users where username='$username'";
$check=$db->query($data);
$response=$check->fetch_assoc();
$storage=$response['storage'];
$used=$response['used_storage'];
$plans=$response['plans'];
if($plans == 'starter' || $plans == 'free')
{
$display="d-block";	
echo $used."/".$storage."MB";
$per=round((($used*100)/$storage),2);
$color="";
if($per>80)
{
	$color="bg-danger";
}
else
{
	$color="bg-primary";
}

}
else
{
	echo "Used storage : ".$used."MB";
	$display="d-none";
}
?>
</span>
<div class="progress w-50 my-2<?php echo $display; ?>" style="height:8px">
<div class="progress-bar <?php echo $color; ?>" style="width:<?php echo $per."%"; ?>">
</div>
</div>
<div>
</div>
</div>
</div>
<div class="col-md-6 p-5 border"></div>
<div class="col-md-3 p-5 border">
<div class="w-100 py-3 bg-white mb-5 rounded-lg shadow-lg d-flex flex-column justify-content-center align-items-center">
<a href="gallery.php" class="image-link"><i class="fa fa-image " style="font-size:80px;color:blue"></i></a>
<h5>GALLERY</h5>
<span class="photo-count">
<?php
require("../php/database.php");
$id="select id from users where username='$username'";
$data=$db->query($id);
$get_id=$data->fetch_assoc();
$table_name="user_".$get_id['id'];
$count_photo="select count(id) as total from $table_name";
$pic=$db->query($count_photo);
$pic_no=$pic->fetch_assoc();
echo $pic_no['total']." PHOTO";
$_SESSION['table_name']=$table_name;
?>
</span>
<div>
</div>
</div>
<!------payement-------------->
<div class="w-100 py-3 bg-white mb-5 rounded-lg shadow-lg d-flex flex-column justify-content-center align-items-center">
<a href="shop.php" class="memory-link"><i class="fa fa-shopping-cart " style="font-size:80px;"></i></a>
<h5>MEMORY SHOPPING</h5>
<span>
START FROM <i class="fa fa-inr"></i>99.00/month
</span>
</div>
</div>
</div>
</div>
</body>
</html>
<!-------check expiry date ----------->
<?php
$current_date=date('Y-m-d');
$data="select plans,expiry_date from users where username='$username'";
$response=$db->query($data);
$output=$response->fetch_assoc();
$expiry_date=$output['expiry_date'];
$plans=$output['plans'];
if($plans != 'free')
{
	$cal_date=new DateTime($expiry_date);
	$cal_date->sub(new DateInterval('P5D'));
	$five_days=$cal_date->format('Y-m-d');
	if($current_date == $five_days)
	{
		echo "<div class='alert alert-warning text-center rounded-0 shadow-lg fixed-top py-3'><i class='fa fa-times-circle close' data-dismiss='alert'></i><b>You have only left 5 days to renew your current plan</b></div>";
	}
	else if($current_date >$five_days)
	{
		$manual_expiry_date=date_create($expiry_date);
		$manual_current_date=date_create($current_date);
		$date_diff=date_diff($manual_current_date,$manual_expiry_date);
		$left_day=$date_diff->format('%a');
		echo "<div class='alert alert-warning text-center rounded-0 shadow-lg fixed-top py-3'>
		<i class='fa fa-times-circle close' data-dismiss='alert'></i>
		<b>You have only left ".$left_day." days to renew your current plan</b>
		</div>";
		if($current_date >=$expiry_date)
		{
			$amount;
			$storage;
			if($plans == 'starter')
			{
				$amount=99;
				$storage=1024;
			}
			else
			{
				$amount=500;
				$storage='unlimited';
			}
			$renew_link="php/payment.php?plan=".$plans."&storage=".$storage."&amount=".$amount;
			$_SESSION['renew']='yes';
			echo "<div class='d-flex alert alert-warning rounded-0 shadow-lg fixed-top'>
			<h4 class='flex-fill'>Plan has expired choose an action</h4>
			<a href='".$renew_link."' class='btn btn-danger mx-3'>Renew old product</a>
			<a href='shop.php' class='btn btn-primary mr-3'>Purchase new Plans</a>
			<a href='php/logout.php' class='btn btn-light shadow-sm'>Logout</a>
			</div>";
			
			echo "<style>
			.upload-icon,.image-link,.memory-link{pointer-events:none}
			</style>";
		}
	}
	
}

?>

<?php
$db->close();
?>
