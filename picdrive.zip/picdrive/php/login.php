<?php
require("database.php");
$username=base64_decode($_POST['username']);
$password=base64_decode($_POST['pass']);
$check="select username from users where username='$username'";
$data=$db->query($check);
if($data->num_rows != 0)
{
	$check_password="select username,password from users where username='$username' AND password='$password'";
	$data1=$db->query($check_password);
	if($data1->num_rows != 0)
	{
		$check_status="select status from users where username='$username' AND password='$password' AND status='active'";
		$data2=$db->query($check_status);
		if($data2->num_rows != 0)
		{
			echo "login success";
			session_start();
			$_SESSION['username']=$username;
		}
		else
		{
			$chek_act="select activation_code from users where username='$username' AND password='$password'";
			$acti_code=$db->query($chek_act);
			$get_data=$acti_code->fetch_assoc(); 
			$final_data=$get_data['activation_code'];
			$check_mail=mail($username,"picdrive verification","thanks for you choosing our product your activation code is here :".$final_data);
			if($check_mail == true)
			{
			echo "login pending";
			
			
			}
		}
	}
	else
	{
		echo "password wrong";
	}
}
else
{
	echo "not found";
}


?>

<?php
$db->close();
?>