<?php
require("database.php");

$username=base64_decode($_POST['username']);
$change="select username from users where username='$username'";
$data=$db->query($change);
if($data->num_rows != 0)
{
	echo "user found";
}
else
{
	echo "user not found";
}

?>