<?php
require("../php/database.php");
session_start();
$username=$_SESSION['username'];
if(empty($username))
{
	header("Location:../index.php");
	exit;
}

$starter='<ul class="list-group w-100">
<li class="list-group-item bg-success">
<h4 class="text-center text-light">STARTER PLAN</h4>
</li>
<li class="list-group-item ">1GB STORAGE</li>
<li class="list-group-item" style="color:#ddd">24*7 TECHNICAL SUPPORT</li>
<li class="list-group-item" style="color:#ddd">INSTANT EMAIL SOLUTION</li>
<li class="list-group-item" style="color:#ddd">DATA SECURITY</li>
<li class="list-group-item" style="color:#ddd">SEO SERVICES</li>
<li class="list-group-item buy-btn" style="cursor:pointer" amount="99" plan="starter" storage="1024">
<h4 class="text-center">
<i class="fa fa-inr"></i>99.00/monthly
</h4>
</li>
</ul>';

$exclusive='<ul class="list-group w-100">
<li class="list-group-item bg-warning">
<h4 class="text-center text-light">EXCLUSIVE PLAN</h4>
</li>
<li class="list-group-item ">1GB STORAGE</li>
<li class="list-group-item" >24*7 TECHNICAL SUPPORT</li>
<li class="list-group-item" >INSTANT EMAIL SOLUTION</li>
<li class="list-group-item" >DATA SECURITY</li>
<li class="list-group-item" >SEO SERVICES</li>
<li class="list-group-item buy-btn" style="cursor:pointer" amount="500" plan="exclusive" storage="unlimited">
<h4 class="text-center">
<i class="fa fa-inr"></i>500.00/monthly
</h4>
</li>
</ul>';

$get_plan="select plans from users where username='$username'";
$response=$db->query($get_plan);
$data=$response->fetch_assoc();
$plan=$data['plans'];
?>

<!DOCTYPE html>
<html>
<head>
<meta lang="en-us">
<meta charset="utf-8">
<meta name="viewport" content= "width = device-width, initial-scale=1">
<title>picdrive</title>
<link rel="stylesheet" href="../style/animate.css">
<link href="https://fonts.googleapis.com/css?family=Francois+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="../style/bootstrap.css">
<script src="../js/jquery.js"></script>
<script src="../js/bootstrap.js"></script>
<script src="js/profile.js"></script>
</head>
<body style="background:#FCD0CF">
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
<a class="navbar-brand" href="#">
<?php
require("../php/database.php");
$username=$_SESSION['username'];
$check="select full_name from users where username='$username'";
$data=$db->query($check);
$get=$data->fetch_assoc();
$name=$get['full_name'];
$_SESSION['buyer_name']=$name;
echo $name;

?>
</a>
<ul class="navbar-nav ml-auto">
<li class="navbar-item">
<a class="nav-link" href="php/logout.php">
<i class="fa fa-sign-out" style="font-size:18px"></i>
Logout
</a>
</li>
</ul>
</nav>
<br>
<div class="container-fluid">
<div class="row">
<div class="col-md-6 p-5">
<?php
if($plan == 'free')
{
	echo $starter;
}
else if($plan == 'starter')
{
	echo "<button class='btn bg-primary text-light'>You are using starter plan .Purchase unlimited plan to unlimited storage</button>";
}

?>
</div>

<div class="col-md-6 p-5">
<?php
if($plan == 'free')
{
	echo $exclusive;
}
else if($plan == 'starter')
{
	echo $exclusive;
}

?>
</div>
</div>
<div class="row">
<div class="col-md-12 text-center p-5">
<?php
if($plan == 'exclusive')
{
	echo "<button class='btn p-5 '><h1>You are using our most expensive plan...</h1></button>";
}

?>
</div>
</div>
</div>
<script>
$(document).ready(function(){
	$(".buy-btn").each(function(){
		$(this).click(function(){
			var amount=$(this).attr("amount");
			var plan=$(this).attr("plan");
			var storage=$(this).attr("storage");
			location.href="php/payment.php?amount="+amount+"&plan="+plan+"&storage="+storage;
		});
	});
});
</script>
</body>
</html>



<?php
$db->close();
?>