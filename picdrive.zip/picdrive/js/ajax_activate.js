$(document).ready(function(){
	$(".activate-btn").click(function(){
		$.ajax({
			type:"post",
			url:"php/valid_activate.php",
			cache:false,
			data:{
				code:$("#code").val(),
				username:$(".email").val()
				},
			beforeSend:function(){
				$(".activate-btn").html("please wait we are checking....");
				$(".activate-btn").attr("disabled","disabled");
			},	
			success:function(response)
			{
				if(response.trim() == "user verified")
					{
					window.location="profile/profile.php"
					}
						else
						{
										$(".activate-btn").html("Activate Now");
										$(".activate-btn").removeAttr("disabled");
										$("#code").val("");
										var notice=document.createElement("DIV");
										notice.className="alert alert-warning";
										notice.innerHTML="<b>Wrong activation code</b>";
										$(".signup-notice").append(notice);
										setTimeout(function(){
											$(".signup-notice").html("");
										},3000);
						}
			}
		});
	});
});