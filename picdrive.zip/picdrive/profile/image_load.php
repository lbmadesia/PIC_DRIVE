<?php
require("../php/database.php");
session_start();
$table_name=$_SESSION['table_name'];
$start=$_POST['start'];
$end=$_POST['end'];
$get_image_path="select * from $table_name Order BY id  ASC LIMIT $start,$end";
$response=$db->query($get_image_path);
while($image_path=$response->fetch_assoc())
{
	$image_name=pathinfo($image_path['image_name']);
	$pic_name=$image_name['filename'];
	$path=str_replace("../","",$image_path['image_path']);
	$thumb_path=str_replace("../","",$image_path['thumb_path']);
	echo "<div class='col-md-3 px-5'>
	<div class='card mb-5 shadow-lg'>
	<div class='card-body d-flex justify-content-center align-items-center'>
	<img src='$thumb_path' width='100' height='100' class='rounded-circle pic' data-location='".$path."'>
	</div>
	<div class='card-footer d-flex justify-content-around  align-items-center'>
	<span>".$image_name['filename']."</span>
	<i class='fa fa-save save-icon d-none' data-location='".$path."'></i>
	<i class='fa fa-spinner fa-spin loader d-none' data-location='".$path."'></i>
	<i class='fa fa-edit edit-icon' data-location='".$path."'></i>
	<i class='fa fa-download download-icon' data-location='".$path."' file-name='".$pic_name."'></i>
	<i class='fa fa-trash delete-icon' data-location='".$path."'></i>
	</div>
	</div>
	</div>";
	
}

?>