<?php
require("../../php/database.php");
session_start();
$username=$_SESSION['username']; 
$data="select plans,storage,used_storage from users where username='$username'";
$check=$db->query($data);
$response=$check->fetch_assoc();
$plan=$response['plans'];
if($plan == 'starter' || $plan == 'free')
{
$storage=$response['storage'];
$used=$response['used_storage'];
$free=$storage-$used;
$per=round((($used*100)/$storage),2);
$output=[$used."/".$storage."MB",$free.'MB',$per];
echo json_encode($output);
$color="";
if($per>80)
{
	$color="bg-danger";
}
else
{
	$color="bg-primary";
}
}
else
{
	$output=["Used Storage : ".$response['used_storage'].'MB','UNLIMITED',0];
	echo json_encode($output);
}
?>


<?php
$db->close();
?>