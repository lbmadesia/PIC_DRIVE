$(document).ready(function(){
	$(".email").on("change",function(){
		if($(this).val() != "")
		{
			$.ajax({
				type:"post",
				url:"php/check_user.php",
				cache:false,
				data:{username:btoa($(this).val())},
				beforeSend:function(){
					$(".email-icon").css("display","block");
				},
				success:function(response){
					if(response.trim() == "user found")
					{
						$(".email-icon").removeClass("fa fa-circle-o-notch fa-spin");
						$(".email-icon").addClass("fa fa-times-circle text-warning");
						$(".submit-btn").attr("disabled","disabled");
						alert(response);
					}
					else
					{
						$(".email-icon").removeClass("fa fa-circle-o-notch fa-spin");
						$(".email-icon").addClass("fa fa-check-circle text-primary");
						$(".submit-btn").removeAttr("disabled");
						alert(response);
					}
				}
				
			});
		}
	});
});